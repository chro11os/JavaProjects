package org.nbguzman.hive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiveApplicationTests {

	@Test
	void contextLoads() {

	}

}
